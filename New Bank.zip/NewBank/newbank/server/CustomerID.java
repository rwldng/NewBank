package newbank.server;

public class CustomerID {
	private String key;
	
	public CustomerID(String key) {
		this.key = key;
	}
	
	public String getKey() {
		return key;
	}
}
